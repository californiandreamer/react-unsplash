import React from "react";
import s from "./ResultsPage.module.css";
import Search from "../../misc/Search/Search";

const ResultsPage = (props) => {
    return (
        <div>
            <Search grayBg />
        </div>
    );
};

export default ResultsPage;
